package com.test.entity;

import lombok.Data;

@Data
public class Borrow {
    int id;
    int uid;
    int bid;
}