package com.test.entity;

import lombok.Data;

@Data
public class User {
    int uid;
    String name;
    String sex;
}